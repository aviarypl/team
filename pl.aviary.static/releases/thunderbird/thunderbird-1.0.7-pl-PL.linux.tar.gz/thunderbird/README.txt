Informacje dotycące instalacji, korzystania z programu oraz jego
konfiguracji, a także lista znanych błędów wydania dostępne są
na: http://getthunderbird.com/releases/

Powyższa strona zawiera także informacje odnośnie radzenia sobie z 
problemami, które użytkownicy mogą  napotkać podczas użytkowania
programu.

                     ..::Dodatkowe informacje::..
 Polska strona Mozilli Thunderbird:    http://www.thunderbird.pl/
 Polskie centrum Mozilli:              http://www.mozillaPL.org/
 Polskie forum pomocy użytkownikom:    http://mozillaPL.org/forum/